package fr.einfolearning.premierprojet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("Information","Farida va vous affiche une information générale");
        Log.d("Information","Farida va vous affiche une information générale");
        Log.w("Information","Farida va vous affiche une information de warning");
        Log.e("Information","Farida va vous affiche une erreur");

    }
}